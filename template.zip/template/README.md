# stock-management
This is RDM's stock management program
